# Giai đoạn 1 chưa bật minify. Giữ file này để cấu hình shrinker ở các giai đoạn sau.
