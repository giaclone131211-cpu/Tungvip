package com.intruderguard.app.capture

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import androidx.core.content.ContextCompat
import com.intruderguard.app.R
import java.util.concurrent.atomic.AtomicBoolean

/** Camera2 engine. Không tạo preview/UI; trả về JPEG trong RAM để mã hóa ngay. */
class CameraCaptureEngine(context: Context) {
    private val appContext = context.applicationContext

    fun capture(onCameraOpened: () -> Unit, onResult: (ByteArray?, Throwable?) -> Unit) {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            onResult(null, SecurityException(appContext.getString(R.string.msg_camera_permission_missing)))
            return
        }

        val thread = HandlerThread("IntruderGuard-Camera2").apply { start() }
        val handler = Handler(thread.looper)
        val finished = AtomicBoolean(false)
        val triggered = AtomicBoolean(false)
        var camera: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var jpegReader: ImageReader? = null
        var previewReader: ImageReader? = null
        val timeoutMs = appContext.resources.getInteger(R.integer.camera_timeout_ms).toLong()

        fun finish(bytes: ByteArray? = null, error: Throwable? = null) {
            if (!finished.compareAndSet(false, true)) {
                bytes?.fill(0)
                return
            }
            runCatching { session?.close() }
            runCatching { camera?.close() }
            runCatching { jpegReader?.close() }
            runCatching { previewReader?.close() }
            runCatching { thread.quitSafely() }
            onResult(bytes, error)
        }

        handler.postDelayed({
            if (!finished.get()) finish(null, IllegalStateException(appContext.getString(R.string.msg_camera_timeout, timeoutMs)))
        }, timeoutMs)

        try {
            val manager = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            } ?: run {
                finish(null, IllegalStateException(appContext.getString(R.string.msg_camera_unavailable)))
                return
            }
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val streamMap = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: run {
                    finish(null, IllegalStateException(appContext.getString(R.string.msg_camera_stream_map_missing)))
                    return
                }
            val maxWidth = appContext.resources.getInteger(R.integer.camera_max_width)
            val maxHeight = appContext.resources.getInteger(R.integer.camera_max_height)
            val jpegSizes = streamMap.getOutputSizes(ImageFormat.JPEG)?.toList().orEmpty()
            val jpegSize = chooseSize(jpegSizes, maxWidth, maxHeight)
                ?: run {
                    finish(null, IllegalStateException(appContext.getString(R.string.msg_camera_jpeg_unsupported)))
                    return
                }
            val previewSizes = streamMap.getOutputSizes(ImageFormat.YUV_420_888)?.toList().orEmpty()
            val previewSize = chooseSize(
                previewSizes,
                appContext.resources.getInteger(R.integer.camera_preview_max_width),
                appContext.resources.getInteger(R.integer.camera_preview_max_height)
            )
                ?: run {
                    finish(null, IllegalStateException(appContext.getString(R.string.msg_camera_yuv_unsupported)))
                    return
                }

            jpegReader = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 2)
            previewReader = ImageReader.newInstance(previewSize.width, previewSize.height, ImageFormat.YUV_420_888, 3)
            jpegReader?.setOnImageAvailableListener({ reader ->
                if (finished.get()) {
                    runCatching { reader.acquireLatestImage()?.close() }
                    return@setOnImageAvailableListener
                }
                try {
                    val image = reader.acquireLatestImage()
                    if (image == null) {
                        finish(null, IllegalStateException(appContext.getString(R.string.msg_image_reader_empty)))
                    } else {
                        val jpegBytes = image.use { imageData ->
                            val buffer = imageData.planes.firstOrNull()?.buffer
                                ?: throw IllegalStateException(appContext.getString(R.string.msg_jpeg_plane_missing))
                            ByteArray(buffer.remaining()).also { buffer.get(it) }
                        }
                        finish(jpegBytes, null)
                    }
                } catch (error: Throwable) {
                    finish(null, error)
                }
            }, handler)
            previewReader?.setOnImageAvailableListener({ reader ->
                runCatching { reader.acquireLatestImage()?.close() }
            }, handler)

            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(openedCamera: CameraDevice) {
                    if (finished.get()) {
                        openedCamera.close()
                        return
                    }
                    camera = openedCamera
                    onCameraOpened()
                    try {
                        val outputs = listOfNotNull(previewReader?.surface, jpegReader?.surface)
                        openedCamera.createCaptureSession(outputs, object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(configuredSession: CameraCaptureSession) {
                                if (finished.get()) {
                                    configuredSession.close()
                                    return
                                }
                                session = configuredSession
                                try {
                                    val previewRequest = openedCamera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                                        addTarget(requireNotNull(previewReader).surface)
                                        set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                                    }.build()
                                    var stableFrames = 0
                                    val requiredFrames = appContext.resources.getInteger(R.integer.camera_stable_frame_count)
                                    configuredSession.setRepeatingRequest(previewRequest, object : CameraCaptureSession.CaptureCallback() {
                                        override fun onCaptureCompleted(
                                            session: CameraCaptureSession,
                                            request: CaptureRequest,
                                            result: TotalCaptureResult
                                        ) {
                                            if (finished.get() || triggered.get()) return
                                            stableFrames += 1
                                            val aeState = result.get(CaptureResult.CONTROL_AE_STATE)
                                            if (aeState == CaptureResult.CONTROL_AE_STATE_CONVERGED || stableFrames >= requiredFrames) {
                                                if (!triggered.compareAndSet(false, true)) return
                                                try {
                                                    configuredSession.stopRepeating()
                                                    val sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
                                                    val stillRequest = openedCamera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                                                        addTarget(requireNotNull(jpegReader).surface)
                                                        set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                                                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                                                        set(CaptureRequest.JPEG_ORIENTATION, sensorOrientation)
                                                    }.build()
                                                    configuredSession.capture(stillRequest, object : CameraCaptureSession.CaptureCallback() {
                                                        override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                                                            finish(null, CameraAccessException(CameraAccessException.CAMERA_ERROR, appContext.getString(R.string.msg_capture_failure_reason, failure.reason)))
                                                        }
                                                        override fun onCaptureSequenceAborted(session: CameraCaptureSession, sequenceId: Int) {
                                                            finish(null, IllegalStateException(appContext.getString(R.string.msg_capture_sequence_aborted, sequenceId)))
                                                        }
                                                    }, handler)
                                                } catch (error: Throwable) {
                                                    finish(null, error)
                                                }
                                            }
                                        }
                                    }, handler)
                                } catch (error: Throwable) {
                                    finish(null, error)
                                }
                            }

                            override fun onConfigureFailed(failedSession: CameraCaptureSession) {
                                finish(null, IllegalStateException(appContext.getString(R.string.msg_capture_session_failed)))
                            }
                        }, handler)
                    } catch (error: Throwable) {
                        finish(null, error)
                    }
                }

                override fun onDisconnected(disconnectedCamera: CameraDevice) {
                    disconnectedCamera.close()
                    finish(null, CameraAccessException(CameraAccessException.CAMERA_DISCONNECTED))
                }

                override fun onError(errorCamera: CameraDevice, errorCode: Int) {
                    errorCamera.close()
                    finish(null, CameraAccessException(CameraAccessException.CAMERA_ERROR, appContext.getString(R.string.msg_camera_error_code, errorCode)))
                }
            }, handler)
        } catch (error: Throwable) {
            finish(null, error)
        }
    }

    private fun chooseSize(sizes: List<Size>, maxWidth: Int, maxHeight: Int): Size? {
        if (sizes.isEmpty()) return null
        return sizes.filter { it.width <= maxWidth && it.height <= maxHeight }
            .maxByOrNull { it.width.toLong() * it.height.toLong() }
            ?: sizes.minByOrNull { it.width.toLong() * it.height.toLong() }
    }
}
