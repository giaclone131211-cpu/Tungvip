package com.intruderguard.app.detection

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.intruderguard.app.R
import com.intruderguard.app.capture.NotificationHelper
import com.intruderguard.app.capture.ProtectionState
import com.intruderguard.app.storage.DiagnosticLogger

/** Sau reboot chỉ nhắc người dùng bật lại; tuyệt đối không tự khởi động camera từ nền. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED || !ProtectionState.wasRequested(context)) return
        ProtectionState.setActive(context, false)
        val shown = NotificationHelper.showReenablePrompt(context)
        if (shown) {
            DiagnosticLogger.info(context, context.getString(R.string.step_notification), context.getString(R.string.msg_boot_notice))
        } else {
            DiagnosticLogger.warning(context, context.getString(R.string.step_notification), context.getString(R.string.notification_permission_required))
            Log.w("IntruderGuard", context.getString(R.string.log_boot_notice_failed))
        }
    }
}
