package com.intruderguard.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.intruderguard.app.capture.ProtectionService
import com.intruderguard.app.capture.ProtectionState
import com.intruderguard.app.detection.FailedAttemptReceiver
import com.intruderguard.app.storage.DiagnosticLogger
import com.intruderguard.app.ui.IntruderGuardTheme
import com.intruderguard.app.ui.LockedScreen
import com.intruderguard.app.ui.MainScreen
import com.intruderguard.app.ui.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels { MainViewModel.Factory(application) }
    private val contentUnlocked = androidx.compose.runtime.mutableStateOf(false)
    private val adminActive = androidx.compose.runtime.mutableStateOf(false)
    private val protectionActive = androidx.compose.runtime.mutableStateOf(false)
    private val authMessage = androidx.compose.runtime.mutableStateOf<String?>(null)
    private var authPromptActive = false
    private var shouldStartAuthOnResume = false
    private var statusReceiverRegistered = false

    private val statusReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ProtectionService.ACTION_STATUS_CHANGED) refreshProtectionState()
        }
    }

    private val permissionsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val cameraGranted = results[Manifest.permission.CAMERA] == true || hasPermission(Manifest.permission.CAMERA)
        val notificationsGranted = Build.VERSION.SDK_INT < 33 ||
            results[Manifest.permission.POST_NOTIFICATIONS] == true || hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        when {
            !cameraGranted -> showToast(getString(R.string.camera_permission_required))
            !notificationsGranted -> showToast(getString(R.string.notification_permission_required))
            else -> startProtection()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val gateEnabled = ProtectionState.prefs(this).getBoolean(ProtectionState.KEY_AUTH_GATE_ENABLED, false)
        contentUnlocked.value = !gateEnabled
        shouldStartAuthOnResume = gateEnabled
        refreshAdminState()
        refreshProtectionState()

        setContent {
            IntruderGuardTheme {
                if (contentUnlocked.value) {
                    MainScreen(
                        viewModel = viewModel,
                        isAdminActive = adminActive.value,
                        isProtectionActive = protectionActive.value,
                        onEnableAdmin = ::openAdminActivation,
                        onEnableProtection = ::requestEnableProtection,
                        onDisableProtection = ::disableProtection,
                        onTestCapture = ::testCapture
                    )
                } else {
                    LockedScreen(
                        errorMessage = authMessage.value,
                        onRetry = ::authenticateToOpen
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (!statusReceiverRegistered) {
            registerReceiver(statusReceiver, IntentFilter(ProtectionService.ACTION_STATUS_CHANGED), Context.RECEIVER_NOT_EXPORTED)
            statusReceiverRegistered = true
        }
        refreshAdminState()
        refreshProtectionState()
    }

    override fun onResume() {
        super.onResume()
        refreshAdminState()
        refreshProtectionState()
        val gateEnabled = ProtectionState.prefs(this).getBoolean(ProtectionState.KEY_AUTH_GATE_ENABLED, false)
        if (gateEnabled && !contentUnlocked.value && shouldStartAuthOnResume && !authPromptActive) {
            shouldStartAuthOnResume = false
            authenticateToOpen()
        }
    }

    override fun onStop() {
        if (statusReceiverRegistered) {
            runCatching { unregisterReceiver(statusReceiver) }
            statusReceiverRegistered = false
        }
        if (ProtectionState.prefs(this).getBoolean(ProtectionState.KEY_AUTH_GATE_ENABLED, false)) {
            contentUnlocked.value = false
            shouldStartAuthOnResume = true
            authMessage.value = null
        }
        super.onStop()
    }

    private fun refreshAdminState() {
        val manager = getSystemService(DevicePolicyManager::class.java)
        adminActive.value = manager.isAdminActive(ComponentName(this, FailedAttemptReceiver::class.java))
    }

    private fun refreshProtectionState() {
        protectionActive.value = ProtectionState.isActive(this)
    }

    private fun openAdminActivation() {
        val component = ComponentName(this, FailedAttemptReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_explanation))
        startActivity(intent)
    }

    private fun requestEnableProtection() {
        if (!adminActive.value) {
            showToast(getString(R.string.admin_required_first))
            openAdminActivation()
            return
        }
        val missing = buildList {
            if (!hasPermission(Manifest.permission.CAMERA)) add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (missing.isNotEmpty()) permissionsLauncher.launch(missing.toTypedArray()) else startProtection()
    }

    private fun startProtection() {
        if (!adminActive.value) {
            showToast(getString(R.string.admin_required_first))
            return
        }
        try {
            ProtectionService.start(this)
        } catch (error: Exception) {
            Log.e("IntruderGuard", getString(R.string.log_service_start_failed), error)
            DiagnosticLogger.error(
                this,
                getString(R.string.step_service),
                getString(R.string.msg_service_start_failed, error.message ?: error.javaClass.simpleName)
            )
            showToast(getString(R.string.msg_service_start_failed, error.message ?: error.javaClass.simpleName))
        }
    }

    private fun disableProtection() {
        ProtectionService.stop(this)
        refreshProtectionState()
    }

    private fun testCapture() {
        if (!ProtectionState.isActive(this)) {
            showToast(getString(R.string.service_already_stopped))
            return
        }
        lifecycleScope.launch {
            runCatching {
                val eventId = viewModel.createTestEvent()
                ProtectionService.requestCapture(this@MainActivity, eventId)
            }.onFailure { error ->
                DiagnosticLogger.error(this@MainActivity, getString(R.string.step_capture), error.message ?: error.javaClass.simpleName)
                showToast(getString(R.string.msg_camera_failed, error.message ?: error.javaClass.simpleName))
            }
        }
    }

    private fun authenticateToOpen() {
        if (authPromptActive) return
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val manager = BiometricManager.from(this)
        val availability = manager.canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
            authMessage.value = getString(R.string.msg_auth_unavailable)
            return
        }

        authPromptActive = true
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                authPromptActive = false
                authMessage.value = null
                contentUnlocked.value = true
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                authPromptActive = false
                authMessage.value = getString(R.string.msg_auth_cancelled)
            }

            override fun onAuthenticationFailed() {
                authMessage.value = getString(R.string.msg_auth_cancelled)
            }
        })
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.auth_title))
            .setSubtitle(getString(R.string.auth_subtitle))
            .setAllowedAuthenticators(authenticators)
            .setConfirmationRequired(false)
            .build()
        prompt.authenticate(promptInfo)
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
