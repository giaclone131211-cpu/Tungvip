package com.intruderguard.app.capture

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.util.Log
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.intruderguard.app.R
import com.intruderguard.app.crypto.PhotoEnvelopeCrypto
import com.intruderguard.app.storage.AppDatabase
import com.intruderguard.app.storage.CaptureState
import com.intruderguard.app.storage.DiagnosticLogger
import com.intruderguard.app.storage.SettingsRepository
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Foreground service khởi động từ nút bấm khi Activity đang hiển thị. */
class ProtectionService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val captureInProgress = AtomicBoolean(false)
    private var receiverRegistered = false

    private val captureReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_CAPTURE) return
            val eventId = intent.getLongExtra(EXTRA_EVENT_ID, -1L)
            if (eventId > 0) handleCapture(eventId)
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerReceiver(captureReceiver, IntentFilter(ACTION_CAPTURE), Context.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ProtectionState.setRequested(this, false)
            DiagnosticLogger.info(this, getString(R.string.step_service), getString(R.string.msg_service_stopped))
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                throw SecurityException(getString(R.string.msg_camera_permission_missing))
            }
            ServiceCompat.startForeground(
                this,
                NotificationHelper.SERVICE_NOTIFICATION_ID,
                NotificationHelper.protectionNotification(this),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
            ProtectionState.setActive(this, true)
            ProtectionState.setRequested(this, true)
            ProtectionState.prefs(this).edit().putBoolean(ProtectionState.KEY_AUTH_GATE_ENABLED, true).apply()
            DiagnosticLogger.info(this, getString(R.string.step_service), getString(R.string.msg_service_started))
            publishStatus()
        } catch (error: Exception) {
            ProtectionState.setActive(this, false)
            DiagnosticLogger.error(
                this,
                getString(R.string.step_service),
                getString(R.string.msg_service_start_failed, error.message ?: error.javaClass.simpleName)
            )
            publishStatus()
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun handleCapture(eventId: Long) {
        if (!ProtectionState.isActive(this)) {
            markCapture(eventId, CaptureState.SKIPPED_NO_SERVICE, null, getString(R.string.msg_service_not_running))
            DiagnosticLogger.warning(this, getString(R.string.step_service), getString(R.string.msg_service_not_running))
            return
        }
        if (!captureInProgress.compareAndSet(false, true)) {
            val detail = getString(R.string.msg_camera_failed, getString(R.string.msg_capture_busy))
            markCapture(eventId, CaptureState.FAILED, null, detail)
            DiagnosticLogger.warning(this, getString(R.string.step_capture), detail)
            return
        }

        serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).captureEventDao()
            try {
                val now = System.currentTimeMillis()
                val cooldown = SettingsRepository(applicationContext).captureCooldownMillis.first()
                val lastCapture = ProtectionState.prefs(this@ProtectionService).getLong(ProtectionState.KEY_LAST_CAPTURE_TIME, 0L)
                if (lastCapture > 0 && now - lastCapture < cooldown) {
                    dao.updateCapture(eventId, CaptureState.SKIPPED_COOLDOWN, null, getString(R.string.msg_capture_throttled))
                    DiagnosticLogger.warning(this@ProtectionService, getString(R.string.step_capture), getString(R.string.msg_capture_throttled))
                    captureInProgress.set(false)
                    return@launch
                }
                ProtectionState.prefs(this@ProtectionService).edit().putLong(ProtectionState.KEY_LAST_CAPTURE_TIME, now).apply()
                dao.updateCapture(eventId, CaptureState.CAPTURING, null, null)
                DiagnosticLogger.info(this@ProtectionService, getString(R.string.step_camera), getString(R.string.msg_camera_opening))

                CameraCaptureEngine(this@ProtectionService).capture(
                    onCameraOpened = {
                        DiagnosticLogger.info(this@ProtectionService, getString(R.string.step_camera), getString(R.string.msg_camera_opened))
                    },
                    onResult = { jpegBytes, error ->
                        if (error != null || jpegBytes == null) {
                            val detail = getString(R.string.msg_camera_failed, error?.message ?: getString(R.string.msg_capture_no_bytes))
                            DiagnosticLogger.error(this@ProtectionService, getString(R.string.step_camera), detail)
                            serviceScope.launch {
                                dao.updateCapture(eventId, CaptureState.FAILED, null, detail)
                                captureInProgress.set(false)
                            }
                        } else {
                            DiagnosticLogger.info(this@ProtectionService, getString(R.string.step_capture), getString(R.string.msg_capture_done))
                            serviceScope.launch encryptAndSave@ {
                                var encryptedPayload: ByteArray? = null
                                try {
                                    val encrypted = try {
                                        PhotoEnvelopeCrypto.encrypt(this@ProtectionService, jpegBytes)
                                    } catch (cryptoError: Exception) {
                                        jpegBytes.fill(0)
                                        val detail = getString(
                                            R.string.msg_crypto_failed,
                                            cryptoError.message ?: cryptoError.javaClass.simpleName
                                        )
                                        dao.updateCapture(eventId, CaptureState.FAILED, null, detail)
                                        DiagnosticLogger.error(this@ProtectionService, getString(R.string.step_crypto), detail)
                                        return@encryptAndSave
                                    }
                                    encryptedPayload = encrypted
                                    jpegBytes.fill(0)
                                    DiagnosticLogger.info(this@ProtectionService, getString(R.string.step_crypto), getString(R.string.msg_crypto_done))
                                    val fileName = try {
                                        saveEncryptedPayload(eventId, encrypted)
                                    } catch (storageError: Exception) {
                                        val detail = getString(
                                            R.string.msg_storage_failed,
                                            storageError.message ?: storageError.javaClass.simpleName
                                        )
                                        dao.updateCapture(eventId, CaptureState.FAILED, null, detail)
                                        DiagnosticLogger.error(this@ProtectionService, getString(R.string.step_storage), detail)
                                        return@encryptAndSave
                                    }
                                    dao.updateCapture(eventId, CaptureState.ENCRYPTED, fileName, null)
                                    DiagnosticLogger.info(this@ProtectionService, getString(R.string.step_storage), getString(R.string.msg_storage_done))
                                } catch (unexpectedError: Exception) {
                                    val detail = getString(R.string.msg_storage_failed, unexpectedError.message ?: unexpectedError.javaClass.simpleName)
                                    runCatching { dao.updateCapture(eventId, CaptureState.FAILED, null, detail) }
                                    DiagnosticLogger.error(this@ProtectionService, getString(R.string.step_storage), detail)
                                } finally {
                                    encryptedPayload?.fill(0)
                                    jpegBytes.fill(0)
                                    captureInProgress.set(false)
                                }
                            }
                        }
                    }
                )
            } catch (error: Exception) {
                val detail = getString(R.string.msg_camera_failed, error.message ?: error.javaClass.simpleName)
                dao.updateCapture(eventId, CaptureState.FAILED, null, detail)
                DiagnosticLogger.error(this@ProtectionService, getString(R.string.step_capture), detail)
                captureInProgress.set(false)
            }
        }
    }

    private fun saveEncryptedPayload(eventId: Long, payload: ByteArray): String {
        val directory = File(filesDir, "captures")
        if (!directory.exists() && !directory.mkdirs()) {
            throw IllegalStateException(getString(R.string.msg_capture_directory_failed))
        }
        val fileName = "event_${eventId}_${System.currentTimeMillis()}.igc"
        val finalFile = File(directory, fileName)
        val tempFile = File(directory, "$fileName.tmp")
        try {
            FileOutputStream(tempFile).use { output ->
                output.write(payload)
                output.fd.sync()
            }
            if (!tempFile.renameTo(finalFile)) {
                throw IllegalStateException(getString(R.string.msg_capture_rename_failed))
            }
            return fileName
        } catch (error: Exception) {
            tempFile.delete()
            finalFile.delete()
            throw error
        }
    }

    private fun markCapture(eventId: Long, state: String, fileName: String?, detail: String) {
        serviceScope.launch {
            runCatching {
                AppDatabase.get(applicationContext).captureEventDao().updateCapture(eventId, state, fileName, detail)
            }
        }
    }

    private fun publishStatus() {
        sendBroadcast(Intent(ACTION_STATUS_CHANGED).setPackage(packageName))
    }

    override fun onDestroy() {
        if (receiverRegistered) runCatching { unregisterReceiver(captureReceiver) }
        ProtectionState.setActive(this, false)
        publishStatus()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_CAPTURE = "com.intruderguard.app.action.CAPTURE_EVENT"
        const val ACTION_STATUS_CHANGED = "com.intruderguard.app.action.SERVICE_STATUS_CHANGED"
        const val ACTION_START = "com.intruderguard.app.action.START_PROTECTION"
        const val ACTION_STOP = "com.intruderguard.app.action.STOP_PROTECTION"
        const val EXTRA_EVENT_ID = "event_id"

        fun requestCapture(context: Context, eventId: Long) {
            context.sendBroadcast(
                Intent(ACTION_CAPTURE)
                    .setPackage(context.packageName)
                    .putExtra(EXTRA_EVENT_ID, eventId)
            )
        }

        fun start(context: Context) {
            val intent = Intent(context, ProtectionService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, ProtectionService::class.java).setAction(ACTION_STOP)
            if (ProtectionState.isActive(context)) context.startService(intent)
            else ProtectionState.setRequested(context, false)
        }
    }
}
