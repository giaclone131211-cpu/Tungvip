package com.intruderguard.app.storage

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "diagnostic_entries")
data class DiagnosticEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val level: String,
    val step: String,
    val message: String
)
