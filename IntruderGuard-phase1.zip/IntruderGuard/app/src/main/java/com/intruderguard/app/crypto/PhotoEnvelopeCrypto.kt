package com.intruderguard.app.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.content.Context
import com.intruderguard.app.R
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import javax.crypto.spec.GCMParameterSpec

/**
 * Mã hóa ảnh ngay trong RAM. Tệp tạo ra chỉ chứa khóa phiên đã bọc + nonce + ciphertext.
 * Khóa riêng RSA được giữ trong Android Keystore; thao tác giải mã sẽ được hoàn thiện ở giai đoạn 2.
 */
object PhotoEnvelopeCrypto {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "intruderguard_envelope_rsa_v1"
    private const val MAGIC = "IGP1"
    private const val GCM_NONCE_BYTES = 12
    private const val GCM_TAG_BITS = 128

    @Synchronized
    fun encrypt(context: Context, plainBytes: ByteArray): ByteArray {
        ensureKeyPair()
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val publicKey = keyStore.getCertificate(KEY_ALIAS)?.publicKey
            ?: error(context.getString(R.string.msg_crypto_public_key_missing))

        val random = SecureRandom()
        val sessionKeyBytes = ByteArray(32).also { random.nextBytes(it) }
        try {
            val sessionKey = SecretKeySpec(sessionKeyBytes, KeyProperties.KEY_ALGORITHM_AES)
            val nonce = ByteArray(GCM_NONCE_BYTES).also { random.nextBytes(it) }
            val aesCipher = Cipher.getInstance("AES/GCM/NoPadding")
            aesCipher.init(Cipher.ENCRYPT_MODE, sessionKey, GCMParameterSpec(GCM_TAG_BITS, nonce))
            val encryptedBytes = aesCipher.doFinal(plainBytes)

            val wrapCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
            wrapCipher.init(Cipher.ENCRYPT_MODE, publicKey)
            val wrappedKey = wrapCipher.doFinal(sessionKeyBytes)

            val result = ByteArrayOutputStream()
            DataOutputStream(result).use { output ->
                output.write(MAGIC.toByteArray(Charsets.US_ASCII))
                output.writeInt(wrappedKey.size)
                output.writeInt(nonce.size)
                output.write(wrappedKey)
                output.write(nonce)
                output.write(encryptedBytes)
            }
            return result.toByteArray()
        } finally {
            sessionKeyBytes.fill(0)
        }
    }

    @Synchronized
    private fun ensureKeyPair() {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        if (keyStore.containsAlias(KEY_ALIAS)) return

        val keyPairGenerator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, KEYSTORE_PROVIDER)
        val authTypes = KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setKeySize(2048)
            .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
            .setUserAuthenticationRequired(true)
            .setUserAuthenticationParameters(30, authTypes)
            .setInvalidatedByBiometricEnrollment(false)
            .build()
        keyPairGenerator.initialize(spec)
        keyPairGenerator.generateKeyPair()
    }
}
