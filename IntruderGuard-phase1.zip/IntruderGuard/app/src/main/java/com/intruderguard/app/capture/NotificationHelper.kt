package com.intruderguard.app.capture

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.intruderguard.app.MainActivity
import com.intruderguard.app.R

object NotificationHelper {
    const val SERVICE_NOTIFICATION_ID = 4101
    private const val UNLOCK_NOTIFICATION_ID = 4102
    private const val REENABLE_NOTIFICATION_ID = 4103
    private const val CHANNEL_STATUS = "intruderguard_status"
    private const val CHANNEL_ALERTS = "intruderguard_alerts"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_STATUS, context.getString(R.string.service_notification_title), NotificationManager.IMPORTANCE_LOW).apply {
                description = context.getString(R.string.service_notification_body)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, context.getString(R.string.unlock_notice_title), NotificationManager.IMPORTANCE_DEFAULT).apply {
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
        )
    }

    fun protectionNotification(context: Context): Notification {
        createChannels(context)
        val openIntent = PendingIntent.getActivity(
            context,
            1,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(context, CHANNEL_STATUS)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(context.getString(R.string.service_notification_title))
            .setContentText(context.getString(R.string.service_notification_body))
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    fun showUnlockSummary(context: Context, count: Int): Boolean {
        if (!canPostNotifications(context)) return false
        createChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(context.getString(R.string.unlock_notice_title))
            .setContentText(context.getString(R.string.unlock_notice_body, count))
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setAutoCancel(true)
            .build()
        return runCatching {
            NotificationManagerCompat.from(context).notify(UNLOCK_NOTIFICATION_ID, notification)
            true
        }.getOrDefault(false)
    }

    fun showReenablePrompt(context: Context): Boolean {
        if (!canPostNotifications(context)) return false
        createChannels(context)
        val openIntent = PendingIntent.getActivity(
            context,
            2,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(context.getString(R.string.re_enable_title))
            .setContentText(context.getString(R.string.re_enable_body))
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .build()
        return runCatching {
            NotificationManagerCompat.from(context).notify(REENABLE_NOTIFICATION_ID, notification)
            true
        }.getOrDefault(false)
    }

    private fun canPostNotifications(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}
