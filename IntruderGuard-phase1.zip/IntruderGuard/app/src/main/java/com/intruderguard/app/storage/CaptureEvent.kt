package com.intruderguard.app.storage

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Một sự kiện phát hiện hoặc chụp thử; metadata nằm trong cơ sở dữ liệu riêng của app. */
@Entity(tableName = "capture_events")
data class CaptureEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val occurredAtMillis: Long,
    val failedAttemptCount: Int,
    val batteryPercent: Int?,
    val kind: String,
    val captureState: String,
    val encryptedImageFile: String? = null,
    val reportedAfterUnlock: Boolean = false,
    val detail: String? = null
)

object EventKind {
    const val PIN_FAILURE = "PIN_FAILURE"
    const val TEST = "TEST"
}

object CaptureState {
    const val WAITING = "WAITING"
    const val CAPTURING = "CAPTURING"
    const val ENCRYPTED = "ENCRYPTED"
    const val SKIPPED_NO_SERVICE = "SKIPPED_NO_SERVICE"
    const val SKIPPED_COOLDOWN = "SKIPPED_COOLDOWN"
    const val FAILED = "FAILED"
}
