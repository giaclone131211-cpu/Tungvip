package com.intruderguard.app.ui

import android.app.Application
import android.os.BatteryManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.intruderguard.app.R
import com.intruderguard.app.storage.AppDatabase
import com.intruderguard.app.storage.CaptureEvent
import com.intruderguard.app.storage.CaptureState
import com.intruderguard.app.storage.DiagnosticLogger
import com.intruderguard.app.storage.EventKind
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val database = AppDatabase.get(application)

    val events = database.captureEventDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val diagnostics = database.diagnosticDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun createTestEvent(): Long {
        val battery = (app.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            .takeIf { it in 0..100 }
        val id = database.captureEventDao().insert(
            CaptureEvent(
                occurredAtMillis = System.currentTimeMillis(),
                failedAttemptCount = 0,
                batteryPercent = battery,
                kind = EventKind.TEST,
                captureState = CaptureState.WAITING
            )
        )
        DiagnosticLogger.info(app, app.getString(R.string.step_event), app.getString(R.string.msg_test_event))
        return id
    }

    fun deleteEvent(eventId: Long) {
        viewModelScope.launch { database.captureEventDao().deleteById(eventId) }
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
