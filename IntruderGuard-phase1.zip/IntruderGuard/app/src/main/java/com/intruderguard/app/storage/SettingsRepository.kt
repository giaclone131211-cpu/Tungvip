package com.intruderguard.app.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.intruderSettings by preferencesDataStore(name = "intruderguard_settings")

/** Cài đặt thay đổi được lưu bằng DataStore; giá trị mặc định nằm trong resources. */
class SettingsRepository(private val context: Context) {
    private val cooldownKey = longPreferencesKey("capture_cooldown_ms")
    private val batteryKey = booleanPreferencesKey("include_battery_percent")

    val captureCooldownMillis: Flow<Long> = context.intruderSettings.data.map { prefs ->
        prefs[cooldownKey] ?: context.resources.getInteger(
            com.intruderguard.app.R.integer.default_capture_cooldown_ms
        ).toLong()
    }

    val includeBatteryPercent: Flow<Boolean> = context.intruderSettings.data.map { prefs ->
        prefs[batteryKey] ?: true
    }

    suspend fun setCaptureCooldownMillis(value: Long) {
        val min = context.resources.getInteger(com.intruderguard.app.R.integer.minimum_capture_cooldown_ms).toLong()
        context.intruderSettings.edit { it[cooldownKey] = value.coerceAtLeast(min) }
    }

    suspend fun setIncludeBatteryPercent(enabled: Boolean) {
        context.intruderSettings.edit { it[batteryKey] = enabled }
    }
}
