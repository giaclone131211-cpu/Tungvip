package com.intruderguard.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import com.intruderguard.app.R
import com.intruderguard.app.capture.ProtectionState
import com.intruderguard.app.storage.CaptureEvent
import com.intruderguard.app.storage.CaptureState
import com.intruderguard.app.storage.DiagnosticEntry
import com.intruderguard.app.storage.EventKind
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    isAdminActive: Boolean,
    isProtectionActive: Boolean,
    onEnableAdmin: () -> Unit,
    onEnableProtection: () -> Unit,
    onDisableProtection: () -> Unit,
    onTestCapture: () -> Unit
) {
    val events by viewModel.events.collectAsState()
    val diagnostics by viewModel.diagnostics.collectAsState()
    val spacingS = dimensionResource(R.dimen.space_s)
    val spacingM = dimensionResource(R.dimen.space_m)
    val spacingL = dimensionResource(R.dimen.space_l)
    val spacingXL = dimensionResource(R.dimen.space_xl)

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = spacingL, vertical = spacingXL),
            verticalArrangement = Arrangement.spacedBy(spacingM)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ShieldMark(Modifier.size(dimensionResource(R.dimen.shield_size)))
                    Column(modifier = Modifier.padding(start = spacingM)) {
                        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.app_tagline), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                StatusCard(isProtectionActive = isProtectionActive, isAdminActive = isAdminActive)
            }
            item {
                Card(
                    shape = RoundedCornerShape(dimensionResource(R.dimen.card_radius)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(spacingL), verticalArrangement = Arrangement.spacedBy(spacingS)) {
                        Text(stringResource(R.string.section_overview), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (isAdminActive) stringResource(R.string.admin_enabled) else stringResource(R.string.admin_missing),
                            color = if (isAdminActive) MaterialTheme.colorScheme.primary else colorResource(R.color.warning_amber),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (!isAdminActive) {
                            Button(
                                onClick = onEnableAdmin,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(dimensionResource(R.dimen.button_radius))
                            ) { Text(stringResource(R.string.enable_admin)) }
                            Text(stringResource(R.string.not_admin_explanation), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (!isProtectionActive) {
                            Button(
                                onClick = onEnableProtection,
                                modifier = Modifier.fillMaxWidth(),
                                enabled = isAdminActive,
                                shape = RoundedCornerShape(dimensionResource(R.dimen.button_radius)),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) { Text(stringResource(R.string.enable_protection)) }
                        } else {
                            Button(
                                onClick = onDisableProtection,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(dimensionResource(R.dimen.button_radius)),
                                colors = ButtonDefaults.buttonColors(containerColor = colorResource(R.color.danger_red))
                            ) { Text(stringResource(R.string.disable_protection)) }
                            OutlinedButton(
                                onClick = onTestCapture,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(dimensionResource(R.dimen.button_radius))
                            ) { Text(stringResource(R.string.test_capture)) }
                        }
                    }
                }
            }
            item {
                Card(
                    shape = RoundedCornerShape(dimensionResource(R.dimen.card_radius)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        stringResource(R.string.protection_warning),
                        modifier = Modifier.padding(spacingL),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            item { SectionHeading(stringResource(R.string.section_events), events.size) }
            if (events.isEmpty()) {
                item { EmptyCard(stringResource(R.string.empty_events)) }
            } else {
                items(events, key = { it.id }) { event -> EventCard(event) }
            }
            item { SectionHeading(stringResource(R.string.section_diagnostics), diagnostics.size) }
            if (diagnostics.isEmpty()) {
                item { EmptyCard(stringResource(R.string.empty_diagnostics)) }
            } else {
                items(diagnostics.take(20), key = { it.id }) { entry -> DiagnosticCard(entry) }
            }
            item {
                Text(
                    stringResource(R.string.language_system),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.fillMaxWidth().padding(top = spacingS),
                )
            }
        }
    }
}

@Composable
private fun StatusCard(isProtectionActive: Boolean, isAdminActive: Boolean) {
    val statusColor = when {
        isProtectionActive && isAdminActive -> MaterialTheme.colorScheme.primary
        else -> colorResource(R.color.danger_red)
    }
    Card(
        shape = RoundedCornerShape(dimensionResource(R.dimen.card_radius)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(dimensionResource(R.dimen.space_l)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ShieldMark(Modifier.size(dimensionResource(R.dimen.status_shield_size)), statusColor)
            Column(modifier = Modifier.weight(1f).padding(start = dimensionResource(R.dimen.space_m))) {
                Text(
                    stringResource(if (isProtectionActive) R.string.status_on else R.string.status_off),
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    stringResource(if (isAdminActive) R.string.admin_enabled else R.string.admin_missing),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (isProtectionActive) RadarRings()
        }
    }
}

@Composable
private fun ShieldMark(modifier: Modifier = Modifier, strokeColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary) {
    Canvas(modifier = modifier) {
        val shield = Path().apply {
            moveTo(size.width * 0.5f, size.height * 0.06f)
            lineTo(size.width * 0.87f, size.height * 0.20f)
            lineTo(size.width * 0.83f, size.height * 0.58f)
            cubicTo(size.width * 0.78f, size.height * 0.76f, size.width * 0.64f, size.height * 0.88f, size.width * 0.5f, size.height * 0.96f)
            cubicTo(size.width * 0.36f, size.height * 0.88f, size.width * 0.22f, size.height * 0.76f, size.width * 0.17f, size.height * 0.58f)
            lineTo(size.width * 0.13f, size.height * 0.20f)
            close()
        }
        drawPath(shield, strokeColor, style = Stroke(width = size.minDimension * 0.045f))
        val check = Path().apply {
            moveTo(size.width * 0.32f, size.height * 0.51f)
            lineTo(size.width * 0.45f, size.height * 0.63f)
            lineTo(size.width * 0.69f, size.height * 0.37f)
        }
        drawPath(check, strokeColor, style = Stroke(width = size.minDimension * 0.055f))
    }
}

@Composable
private fun RadarRings() {
    val borderWidth = dimensionResource(R.dimen.border_thin)
    val color = MaterialTheme.colorScheme.primary
    Canvas(modifier = Modifier.size(dimensionResource(R.dimen.radar_size))) {
        drawCircle(color = color.copy(alpha = 0.20f), radius = size.minDimension * 0.48f, style = Stroke(width = borderWidth.toPx()))
        drawCircle(color = color.copy(alpha = 0.38f), radius = size.minDimension * 0.31f, style = Stroke(width = borderWidth.toPx()))
        drawCircle(color = color, radius = size.minDimension * 0.10f)
    }
}

@Composable
private fun SectionHeading(title: String, count: Int) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(count.toString(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(dimensionResource(R.dimen.card_radius))) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(dimensionResource(R.dimen.space_l)), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun EventCard(event: CaptureEvent) {
    val timestamp = remember(event.occurredAtMillis) {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, Locale.getDefault()).format(Date(event.occurredAtMillis))
    }
    val eventTitle = stringResource(if (event.kind == EventKind.TEST) R.string.event_test else R.string.event_pin_failure)
    val statusText = when (event.captureState) {
        CaptureState.ENCRYPTED -> stringResource(R.string.event_image_saved)
        CaptureState.WAITING, CaptureState.CAPTURING -> stringResource(R.string.event_waiting)
        CaptureState.FAILED -> stringResource(R.string.event_failed)
        CaptureState.SKIPPED_NO_SERVICE, CaptureState.SKIPPED_COOLDOWN -> stringResource(R.string.event_skipped)
        else -> stringResource(R.string.status_checking)
    }
    val stateColor = when (event.captureState) {
        CaptureState.ENCRYPTED -> MaterialTheme.colorScheme.primary
        CaptureState.FAILED -> colorResource(R.color.danger_red)
        CaptureState.SKIPPED_NO_SERVICE, CaptureState.SKIPPED_COOLDOWN -> colorResource(R.color.warning_amber)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(dimensionResource(R.dimen.card_radius))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(dimensionResource(R.dimen.space_l)), verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.space_s))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(eventTitle, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.event_id, event.id), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Text(timestamp, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            if (event.kind != EventKind.TEST && event.failedAttemptCount > 0) {
                Text(stringResource(R.string.event_attempt_number, event.failedAttemptCount), style = MaterialTheme.typography.bodySmall)
            }
            event.batteryPercent?.let { Text(stringResource(R.string.event_battery, it), style = MaterialTheme.typography.bodySmall) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            Text(statusText, color = stateColor, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
            event.detail?.takeIf { it.isNotBlank() }?.let {
                Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun DiagnosticCard(entry: DiagnosticEntry) {
    val timestamp = remember(entry.timestampMillis) {
        DateFormat.getTimeInstance(DateFormat.MEDIUM, Locale.getDefault()).format(Date(entry.timestampMillis))
    }
    val errorLevel = stringResource(R.string.level_error)
    val warningLevel = stringResource(R.string.level_warning)
    val levelColor = when (entry.level) {
        errorLevel -> colorResource(R.color.danger_red)
        warningLevel -> colorResource(R.color.warning_amber)
        else -> MaterialTheme.colorScheme.primary
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(dimensionResource(R.dimen.card_radius))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(dimensionResource(R.dimen.space_l)), verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.space_xs))) {
            Text(stringResource(R.string.diagnostic_label, entry.step, timestamp), color = levelColor, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Text(entry.message, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun LockedScreen(errorMessage: String?, onRetry: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().padding(dimensionResource(R.dimen.space_xl)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            ShieldMark(Modifier.size(dimensionResource(R.dimen.locked_shield_size)))
            Spacer(Modifier.height(dimensionResource(R.dimen.space_l)))
            Text(stringResource(R.string.locked_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(dimensionResource(R.dimen.space_s)))
            Text(stringResource(R.string.locked_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
            errorMessage?.let {
                Spacer(Modifier.height(dimensionResource(R.dimen.space_l)))
                Text(it, color = colorResource(R.color.warning_amber), style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(dimensionResource(R.dimen.space_xl)))
            Button(onClick = onRetry, shape = RoundedCornerShape(dimensionResource(R.dimen.button_radius))) {
                Text(stringResource(R.string.auth_retry))
            }
        }
    }
}
