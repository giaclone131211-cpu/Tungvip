package com.intruderguard.app.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CaptureEventDao {
    @Insert
    suspend fun insert(event: CaptureEvent): Long

    @Query("SELECT * FROM capture_events ORDER BY occurredAtMillis DESC LIMIT 200")
    fun observeRecent(): Flow<List<CaptureEvent>>

    @Query("SELECT COUNT(*) FROM capture_events WHERE reportedAfterUnlock = 0 AND kind = 'PIN_FAILURE'")
    suspend fun countUnreportedPinFailures(): Int

    @Query("UPDATE capture_events SET reportedAfterUnlock = 1 WHERE reportedAfterUnlock = 0 AND kind = 'PIN_FAILURE'")
    suspend fun markAllPinFailuresReported()

    @Query("UPDATE capture_events SET captureState = :state, encryptedImageFile = :fileName, detail = :detail WHERE id = :eventId")
    suspend fun updateCapture(eventId: Long, state: String, fileName: String?, detail: String?)

    @Query("DELETE FROM capture_events WHERE id = :eventId")
    suspend fun deleteById(eventId: Long)

    @Query("DELETE FROM capture_events")
    suspend fun deleteAll()
}

@Dao
interface DiagnosticDao {
    @Insert
    suspend fun insert(entry: DiagnosticEntry)

    @Query("SELECT * FROM diagnostic_entries ORDER BY timestampMillis DESC LIMIT 100")
    fun observeRecent(): Flow<List<DiagnosticEntry>>

    @Query("DELETE FROM diagnostic_entries")
    suspend fun clear()
}

@Database(entities = [CaptureEvent::class, DiagnosticEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun captureEventDao(): CaptureEventDao
    abstract fun diagnosticDao(): DiagnosticDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "intruderguard.db"
            ).build().also { instance = it }
        }
    }
}
