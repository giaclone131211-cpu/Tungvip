package com.intruderguard.app.detection

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.UserHandle
import android.util.Log
import com.intruderguard.app.R
import com.intruderguard.app.capture.ProtectionService
import com.intruderguard.app.capture.ProtectionState
import com.intruderguard.app.capture.NotificationHelper
import com.intruderguard.app.storage.AppDatabase
import com.intruderguard.app.storage.CaptureEvent
import com.intruderguard.app.storage.CaptureState
import com.intruderguard.app.storage.DiagnosticLogger
import com.intruderguard.app.storage.EventKind
import com.intruderguard.app.storage.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Chỉ nhận sự kiện hệ thống watch-login; không đọc nội dung màn hình khóa. */
class FailedAttemptReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        DiagnosticLogger.info(context, context.getString(R.string.step_admin), context.getString(R.string.msg_admin_enabled))
    }

    override fun onDisabled(context: Context, intent: Intent) {
        DiagnosticLogger.warning(context, context.getString(R.string.step_admin), context.getString(R.string.msg_admin_disabled))
    }

    override fun onPasswordFailed(context: Context, intent: Intent, user: UserHandle) {
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val dpm = appContext.getSystemService(DevicePolicyManager::class.java)
                val failedCount = runCatching { dpm.currentFailedPasswordAttempts }.getOrDefault(-1)
                val includeBattery = runCatching { SettingsRepository(appContext).includeBatteryPercent.first() }.getOrDefault(true)
                val batteryPercent = if (includeBattery) {
                    val manager = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).takeIf { it in 0..100 }
                } else null

                val active = ProtectionState.isActive(appContext)
                val event = CaptureEvent(
                    occurredAtMillis = System.currentTimeMillis(),
                    failedAttemptCount = failedCount,
                    batteryPercent = batteryPercent,
                    kind = EventKind.PIN_FAILURE,
                    captureState = if (active) CaptureState.WAITING else CaptureState.SKIPPED_NO_SERVICE,
                    detail = if (active) null else appContext.getString(R.string.msg_event_no_service)
                )
                val dao = AppDatabase.get(appContext).captureEventDao()
                val eventId = dao.insert(event)
                if (failedCount >= 0) {
                    DiagnosticLogger.info(
                        appContext,
                        appContext.getString(R.string.step_event),
                        appContext.getString(R.string.msg_event_received, failedCount)
                    )
                } else {
                    DiagnosticLogger.warning(
                        appContext,
                        appContext.getString(R.string.step_event),
                        appContext.getString(R.string.msg_event_count_unknown)
                    )
                }

                if (active) {
                    ProtectionService.requestCapture(appContext, eventId)
                } else {
                    DiagnosticLogger.warning(
                        appContext,
                        appContext.getString(R.string.step_service),
                        appContext.getString(R.string.msg_service_not_running)
                    )
                }
            } catch (error: Exception) {
                Log.e("IntruderGuard", context.getString(R.string.log_failed_event_write), error)
                DiagnosticLogger.error(
                    context,
                    context.getString(R.string.step_event),
                    context.getString(R.string.msg_camera_failed, error.message ?: error.javaClass.simpleName)
                )
            } finally {
                pending.finish()
            }
        }
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent, user: UserHandle) {
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(context.applicationContext).captureEventDao()
                val count = dao.countUnreportedPinFailures()
                if (count > 0) {
                    val shown = NotificationHelper.showUnlockSummary(context.applicationContext, count)
                    if (shown) dao.markAllPinFailuresReported()
                    else DiagnosticLogger.warning(
                        context,
                        context.getString(R.string.step_notification),
                        context.getString(R.string.notification_permission_required)
                    )
                }
            } catch (error: Exception) {
                Log.e("IntruderGuard", context.getString(R.string.log_unlock_summary_failed), error)
                DiagnosticLogger.error(context, context.getString(R.string.step_notification), error.message ?: error.javaClass.simpleName)
            } finally {
                pending.finish()
            }
        }
    }
}
