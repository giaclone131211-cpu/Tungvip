package com.intruderguard.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import com.intruderguard.app.R

@Composable
fun IntruderGuardTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = colorResource(R.color.neon_green),
        onPrimary = colorResource(R.color.amoled_black),
        secondary = colorResource(R.color.muted_green),
        background = colorResource(R.color.amoled_black),
        onBackground = colorResource(R.color.text_primary),
        surface = colorResource(R.color.surface_dark),
        onSurface = colorResource(R.color.text_primary),
        error = colorResource(R.color.danger_red),
        outline = colorResource(R.color.line_dark),
        surfaceVariant = colorResource(R.color.surface_raised),
        onSurfaceVariant = colorResource(R.color.text_secondary)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
