package com.intruderguard.app.storage

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Ghi nhật ký bất đồng bộ để callback hệ thống không bị chặn bởi I/O. */
object DiagnosticLogger {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun info(context: Context, step: String, message: String) = write(context, context.getString(com.intruderguard.app.R.string.level_info), step, message)
    fun warning(context: Context, step: String, message: String) = write(context, context.getString(com.intruderguard.app.R.string.level_warning), step, message)
    fun error(context: Context, step: String, message: String) = write(context, context.getString(com.intruderguard.app.R.string.level_error), step, message)

    private fun write(context: Context, level: String, step: String, message: String) {
        val appContext = context.applicationContext
        scope.launch {
            runCatching {
                AppDatabase.get(appContext).diagnosticDao().insert(
                    DiagnosticEntry(
                        timestampMillis = System.currentTimeMillis(),
                        level = level,
                        step = step,
                        message = message
                    )
                )
            }
        }
    }
}
