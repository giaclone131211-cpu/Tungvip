package com.intruderguard.app.capture

import android.content.Context

object ProtectionState {
    const val PREFS = "intruderguard_runtime"
    const val KEY_SERVICE_ACTIVE = "service_active"
    const val KEY_PROTECTION_REQUESTED = "protection_requested"
    const val KEY_AUTH_GATE_ENABLED = "auth_gate_enabled"
    const val KEY_LAST_CAPTURE_TIME = "last_capture_time"

    fun isActive(context: Context): Boolean = prefs(context).getBoolean(KEY_SERVICE_ACTIVE, false)
    fun wasRequested(context: Context): Boolean = prefs(context).getBoolean(KEY_PROTECTION_REQUESTED, false)
    fun setActive(context: Context, active: Boolean) {
        prefs(context).edit().putBoolean(KEY_SERVICE_ACTIVE, active).apply()
    }
    fun setRequested(context: Context, requested: Boolean) {
        prefs(context).edit().putBoolean(KEY_PROTECTION_REQUESTED, requested).apply()
    }
    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
