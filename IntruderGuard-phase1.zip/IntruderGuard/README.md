# IntruderGuard — Giai đoạn 1

IntruderGuard là ứng dụng Android native Kotlin + Jetpack Compose để ghi nhận sự kiện nhập sai khóa màn hình trên thiết bị do người dùng tự quản lý. Bản này ưu tiên khả năng phát hiện sự kiện, nhật ký chẩn đoán và thử chụp ảnh bằng Camera2 khi dịch vụ camera foreground đã được người dùng bật rõ ràng.

## Trạng thái giai đoạn 1

**Có trong bản này**

- `DeviceAdminReceiver` chỉ khai báo policy `<watch-login />` và dùng `onPasswordFailed()` / `onPasswordSucceeded()`.
- Đọc bộ đếm bằng `DevicePolicyManager.getCurrentFailedPasswordAttempts()`; không tự suy luận số lần sai.
- Dùng Room cho nhật ký sự kiện và chẩn đoán; dùng Coroutines/Flow để cập nhật giao diện.
- Có `DataStore` cho khoảng nghỉ giữa các lần chụp; mặc định lấy từ `res/values/integers.xml`.
- Foreground Service loại `camera`, chỉ khởi chạy khi người dùng bấm **Bật bảo vệ** trong Activity đang hiển thị và đã cấp quyền camera + thông báo.
- Camera2 chọn camera trước, chờ AE hội tụ hoặc một số khung hình theo cấu hình resource, rồi chụp JPEG.
- Ảnh chỉ tồn tại dưới dạng byte trong RAM cho tới khi mã hóa AES-GCM; khóa phiên được bọc bằng public key RSA trong Android Keystore. Tệp ghi xuống `filesDir/captures` chỉ có dữ liệu mã hóa, không vào Thư viện ảnh.
- `FLAG_SECURE`, loại Activity khỏi Recent Apps, `allowBackup=false`, yêu cầu BiometricPrompt khi mở app sau khi bảo vệ được bật.
- Thông báo tổng hợp số lần sai sau khi mở khóa thành công; nội dung thông báo đặt ở chế độ bí mật trên màn hình khóa.
- Sau khi khởi động lại máy, app chỉ đưa ra thông báo yêu cầu người dùng bật lại — không tự mở camera từ nền.
- Không khai báo quyền `INTERNET`, `RECORD_AUDIO`, vị trí hoặc AccessibilityService.
- Có tiếng Việt và tiếng Anh theo ngôn ngữ hệ thống.

**Chưa có trong giai đoạn 1**

- Quay video 10 giây, mã hóa video bằng Tink StreamingAead, màn hình xem ảnh/giải mã và xuất backup mật khẩu: giai đoạn 2.
- Hoàn thiện giao diện nhật ký, xóa an toàn, giới hạn dung lượng/tuổi dữ liệu, tùy chỉnh nâng cao và hoạt ảnh: giai đoạn 3.
- Module thử nghiệm AccessibilityService cho chuỗi thông báo vân tay: giai đoạn 4; sẽ không đọc nội dung SystemUI ngoài tên gói và từ khóa được người dùng cấu hình.

## Giới hạn Android/Samsung cần biết

Android 14+ hạn chế tạo camera foreground service từ nền. Vì vậy app không cố khởi chạy service camera trong callback `DeviceAdminReceiver` nếu dịch vụ chưa chạy. Khi đã bật bảo vệ từ giao diện, receiver ghi sự kiện vào Room và gửi yêu cầu tới service đang hoạt động. Samsung One UI vẫn có thể từ chối camera khi màn hình khóa, camera đang bị ứng dụng khác sử dụng hoặc thiết bị đang áp dụng chính sách riêng. Những trường hợp đó được ghi thành lỗi; app không đánh dấu ảnh thành công nếu chưa mã hóa và lưu được tệp.

Thông báo foreground cho biết IntruderGuard đang bảo vệ; Android cũng có thể hiển thị chỉ báo quyền riêng tư camera khi camera được mở. Đây không phải ứng dụng ẩn camera.

## Cây thư mục

```text
IntruderGuard/
├── .github/workflows/build-apk.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/intruderguard/app/
│       │   ├── MainActivity.kt
│       │   ├── capture/CameraCaptureEngine.kt
│       │   ├── capture/NotificationHelper.kt
│       │   ├── capture/ProtectionService.kt
│       │   ├── capture/ProtectionState.kt
│       │   ├── crypto/PhotoEnvelopeCrypto.kt
│       │   ├── detection/BootReceiver.kt
│       │   ├── detection/FailedAttemptReceiver.kt
│       │   ├── storage/AppDatabase.kt
│       │   ├── storage/CaptureEvent.kt
│       │   ├── storage/DiagnosticEntry.kt
│       │   ├── storage/DiagnosticLogger.kt
│       │   ├── storage/SettingsRepository.kt
│       │   └── ui/{MainScreen,MainViewModel,IntruderGuardTheme}.kt
│       └── res/{values,values-en,xml}/...
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Build APK không cần Android Studio

### Cách khuyến nghị: GitHub Actions từ điện thoại

1. Tạo một repository GitHub mới (không cần README mặc định), sau đó đẩy toàn bộ mã nguồn của thư mục `IntruderGuard` lên nhánh `main`. Nếu dùng Termux/Linux, sau khi giải nén ZIP, chạy trong thư mục project:

   ```bash
   pkg install git unzip
   git init
   git add .
   git commit -m "IntruderGuard phase 1"
   git branch -M main
   git remote add origin https://github.com/USERNAME/REPOSITORY.git
   git push -u origin main
   ```

   Thay `USERNAME/REPOSITORY` bằng repository của bạn và đăng nhập theo luồng GitHub hiện hành. Không ghi token/mật khẩu vào mã nguồn hay commit.
2. Mở tab **Actions** của repository. Nếu GitHub yêu cầu, bật workflows.
3. Chọn **Build IntruderGuard debug APK** → **Run workflow**.
4. Khi workflow hoàn tất màu xanh, mở run mới nhất và tải artifact **IntruderGuard-debug-apk**. Giải nén artifact sẽ có `app-debug.apk`.
5. Chuyển APK sang Galaxy A15, cho phép trình duyệt/quản lý tệp cài ứng dụng từ nguồn đó, rồi cài đặt. Chỉ tải/cài APK từ repository do chính bạn kiểm soát.

Workflow dùng Java 17, Android SDK platform 35, Build Tools 35.0.0 và Gradle 8.11.1. Bản debug có application ID `com.intruderguard.app.debug`.

### Nếu có môi trường Android SDK cục bộ

```bash
gradle --no-daemon assembleDebug
```

APK đầu ra: `app/build/outputs/apk/debug/app-debug.apk`.

## Cách test trên Samsung Galaxy A15 (Giai đoạn 1)

1. Cài APK và mở app. Xác nhận app không yêu cầu quyền Internet.
2. Chọn **Bật quyền theo dõi nhập sai** và bật quyền quản trị. Android sẽ hiển thị màn hình hệ thống; chỉ có policy `watch-login`.
3. Cấp quyền camera và thông báo khi được hỏi. Nhấn **Bật bảo vệ**. Phải nhìn thấy thông báo ongoing của IntruderGuard; nếu không thấy thông báo, chưa nên xem là đang bảo vệ.
4. Trước khi thử sai PIN, dùng nút **Chụp ảnh thử** khi điện thoại đang mở khóa. Kiểm tra mục Chẩn đoán: cần có bước mở camera, chụp ảnh, mã hóa và lưu trữ; nhật ký sự kiện phải ghi `ENCRYPTED`.
5. Để thử nhận sự kiện, khóa điện thoại và nhập sai PIN một lần. Mở khóa lại và kiểm tra Nhật ký. Trên một số bản firmware, sự kiện có thể được gửi trễ hoặc camera có thể bị chặn; đọc lỗi chính xác trong Chẩn đoán thay vì suy ra thành công.
6. Thử tắt bảo vệ, bật lại và khởi động lại máy. Sau reboot, bản này chỉ gửi thông báo **Chạm để bật lại bảo vệ**; người dùng phải tự mở app và bật lại.
7. Để kiểm tra mã hóa, tệp trong bộ nhớ riêng là `.igc`; không có JPEG rõ trong thư mục app. Giai đoạn 2 sẽ bổ sung đọc/giải mã có xác thực.

**Không dùng người khác làm đối tượng thử chụp khi chưa có sự đồng ý.** Hãy kiểm thử với chính thiết bị và người thử đã biết rõ việc camera có thể được kích hoạt.

## Quyền được khai báo

- `CAMERA`
- `POST_NOTIFICATIONS`
- `FOREGROUND_SERVICE`
- `FOREGROUND_SERVICE_CAMERA`
- `RECEIVE_BOOT_COMPLETED`

Không có `INTERNET`, microphone, location, SMS, contacts hay Accessibility trong giai đoạn này.

## Chưa thể khẳng định

Môi trường tạo gói nguồn không có Android SDK/Gradle cài sẵn để chạy build Android tại chỗ. Workflow GitHub Actions được cung cấp để thực hiện build trên runner có SDK. Trước khi phát hành, cần chạy workflow và thử trực tiếp trên Galaxy A15/One UI để xác minh callback watch-login và hành vi Camera2 khi khóa màn hình.
